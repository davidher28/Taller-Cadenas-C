//DAVID HERNÁNDEZ CÁRDENAS
//TALLER LABORATORIO DE PROGRAMACIÓN
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int x,z;
int NumMagico,V[100];
int main (){
	int o=0;
	NumMagico=rand ()%100;
	printf ("Digite un número\t");
	scanf ("%d",&x);
	V[o]=x;
	o++;
	if (x==NumMagico){
		printf ("El número es correcto\n");
		printf ("Lo lograsté en un sola oportunidad");
	}
	else if (x!=NumMagico && x>NumMagico){
		printf ("El número es menor\n");
	}
	else if (x!=NumMagico && x<NumMagico){
		printf ("El número es mayor\n");
	}
		while (x!=NumMagico){
			printf ("Vuelva a digitar el número\t");
			scanf ("%d",&x);
			V[o]=x;
			o++;
			if (x>NumMagico){
				printf ("El número es menor\n");
			}
			else if (x<NumMagico){
				printf ("El número es mayor\n");
			}
			if (x==NumMagico){
				printf ("El número es correcto\n");
				printf ("Encontró el número en %i %s",o,"intentos\n");
				printf ("Los números fueron: \n");
				break;
			}
			}
	for (z=0;z<o;z++){
		printf ("--%d %s",V[z],"\n");
					}

		
}