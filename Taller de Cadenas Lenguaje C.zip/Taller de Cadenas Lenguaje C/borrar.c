#include <stdio.h>
#include <stdlib.h>


int len(char *sj){
	int i;
	int n=0;
	for(i=0;sj[i]!='\0';i++){
		n++;
	}
	return n;
}
char *asignarcadena (char *s1, char a,char s2[]){
	int x;
	for (x=0;x<len(s1);x++){
		s2[x]=a;
	}
	return s2;
}

void main(int argc, char *argv[]){
	char *s1= argv[1];
	char x= argv[2];
	char *s2=(char *) malloc (len(s1));
	char *s3=asignarcadena(s1,x,s2);
	printf ("%s",s3);
}